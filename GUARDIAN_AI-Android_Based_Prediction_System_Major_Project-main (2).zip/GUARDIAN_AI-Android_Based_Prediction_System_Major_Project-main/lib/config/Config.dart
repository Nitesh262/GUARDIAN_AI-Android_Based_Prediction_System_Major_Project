class Config{
  //final String baseUrl = "https://jalshakti.iwrdup.com";
  final String baseUrl = "http://192.168.1.9:9090";
}
