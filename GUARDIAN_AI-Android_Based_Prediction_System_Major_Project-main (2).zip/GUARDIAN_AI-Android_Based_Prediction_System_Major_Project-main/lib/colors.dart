import 'package:flutter/material.dart';
const Color gcolor = Color(0xFF06F548);
const Color appBarColor = Color(0xFF5AB272);