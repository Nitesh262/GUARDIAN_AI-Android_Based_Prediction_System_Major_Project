package com.example.fake_news_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
