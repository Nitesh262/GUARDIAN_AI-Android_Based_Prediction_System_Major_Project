# GUARDIAN_AI-Android_Based_Prediction_System_Major_Project
 "GUARDIAN AI" is an Android-based prediction system dedicated to improving fake news detection accuracy. Developed as a group project, it features enhanced algorithms, a user-friendly website, a Flutter app, research paper publication, and APIs for seamless integration.  
